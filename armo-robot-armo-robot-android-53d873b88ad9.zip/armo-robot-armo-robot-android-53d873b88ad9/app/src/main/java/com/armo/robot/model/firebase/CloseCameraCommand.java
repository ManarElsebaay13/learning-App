package com.armo.robot.model.firebase;


import com.armo.robot.utils.Constants;

public class CloseCameraCommand extends Command {


    public CloseCameraCommand() {
        super(Constants.ACTION_CLOSE_CAMERA);
    }
}
