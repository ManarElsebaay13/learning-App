package com.armo.robot.model.firebase;


import com.armo.robot.utils.Constants;

public class StopVideoCommand extends Command {


    public StopVideoCommand() {
        super(Constants.ACTION_STOP_VIDEO);
    }
}
