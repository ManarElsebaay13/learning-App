package com.armo.client.model.firebase;



public class Client {

    public String name;

    public Client() {
    }

    public Client(String name) {
        this.name = name;
    }
}
