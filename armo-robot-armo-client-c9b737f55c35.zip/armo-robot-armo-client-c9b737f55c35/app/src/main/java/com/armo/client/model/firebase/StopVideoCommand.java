package com.armo.client.model.firebase;

import com.armo.client.utils.Constants;


public class StopVideoCommand extends Command {


    public StopVideoCommand() {
        super(Constants.ACTION_STOP_VIDEO);
    }
}
