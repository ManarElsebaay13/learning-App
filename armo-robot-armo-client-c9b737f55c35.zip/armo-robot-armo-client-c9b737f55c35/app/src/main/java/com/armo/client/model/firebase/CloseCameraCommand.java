package com.armo.client.model.firebase;

import com.armo.client.utils.Constants;


public class CloseCameraCommand extends Command {


    public CloseCameraCommand() {
        super(Constants.ACTION_CLOSE_CAMERA);
    }
}
