package com.armo.client.model.youtube;


import java.util.List;

public class PlayListItems {

   public List<PlayListItem> items;

}
